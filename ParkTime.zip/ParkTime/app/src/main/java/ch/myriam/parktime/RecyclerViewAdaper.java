package ch.myriam.parktime;

public class RecyclerViewAdaper {
}

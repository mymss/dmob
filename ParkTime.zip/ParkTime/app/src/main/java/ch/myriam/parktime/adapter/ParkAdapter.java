package ch.myriam.parktime.adapter;

import android.view.View;

public class ParkAdapter {

    // boite pour ranger tous les composants à controler
    public void ViewHolder (View itemView) {

    }
}
